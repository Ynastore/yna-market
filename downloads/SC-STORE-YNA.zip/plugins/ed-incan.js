const fetch = require('node-fetch')

let handler = async (m, { yna, command, isCreator, Reply }) => {
  if (!isRegistered(m.sender) && !isCreator)
    return Reply(global.mess.verifikasi);
if (checkLimit(m.sender, global.isPrem(m.sender), isCreator))
return Reply(global.mess.limit);
addLimit(m.sender, global.isPrem(m.sender), isCreator);

    let text = (m.text || '').split(' ').slice(1).join(' ')
    if (!text) return Reply(`❌ Masukkan teks!\nContoh: .${command} yna AI`)

    try {
        m.reply("⏳ Sedang memproses...")

        let api = `https://api.botcahx.eu.org/api/ephoto/incandescent?apikey=${global.apikeyyna}&text=${encodeURIComponent(text)}`

        await yna.sendMessage(m.chat, {
            image: { url: api },
            caption: `💡 *INCANDESCENT EPHOTO*\nText: ${text}`
        }, { quoted: m })

    } catch (e) {
        console.error(e)
        Reply("❌ Terjadi error saat mengambil gambar.")
    }
}

handler.command = ["incandescent"]

module.exports = handler