// © YNA-AI | WhatsApp: 083173403262
// ⚠️ Do not remove this credit

const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")
global.baileys = require('./package.json').dependencies['@whiskeysockets/baileys'] || 'unknown';
global.internalValidationKey = Buffer.from("LICENSE_VALIDATED").toString('base64');

// SETTING BOT
global.owner = '6283173403262'
global.versi = version
global.namaOwner = "Yna Store"
global.packname = 'Yna Ai 2026'
global.botname = 'Yna Ai'
global.botname2 = 'Yna Ai'

global.tempatDB = 'database.json' // Jangan ubah
global.botSecretKey = "alip-ai" // Jangan ubah

global.custompairing = "YNASTORE"; /* custom pairing lu */

// PAKASIR GATEWAY, GANTI PAKE PUNYA LU
global.slug = '';
global.pkasirapikey = '';

// ========= HARGA BUY PREM & SEWA BOT =========
global.harga = {
    prem: "5000",
    sewa: "15000"
}

// ======== APIKEY YNA AI GAUSAH DI UBAH !!! ==============
global.apiyna = "https://alipai-api.vercel.app"
global.btc = "https://api.botcahx.eu.org"
global.apikeyyna = "alipainewapikey"
global.velyn = "https://velyn.mom"
global.apikeyvelyn = "zizzmarket"
global.yudzxml = "https://api.yydz.biz.id"
global.apikeyyud = "alipaixyudz"
global.termai = "https://api.termai.cc"
global.apitermai = "alipxtermai"

// ========PANEL SETTING !!!===============
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://" // Domain lu
global.apikey = "-" //ptla
global.capikey = "-" //ptlc
// ========================================

// Settings Link / Tautan
global.linkOwner = "https://wa.me/6283173403262"
global.linkGrup = "https://chat.whatsapp.com/JYlAqqZQh07HupHeeQHMBF"

// Delay Jpm & Pushctc || 1000 = 1detik
global.delayJpm = 3000
global.delayPushkontak = 6000

// Settings Channel / Saluran
global.linkSaluran = "https://whatsapp.com/channel/0029VbAZ4XL8aKvOd4rMv026"
global.idSaluran = "120363419968683066@newsletter"
global.namaSaluran = "𝙔𝙉𝘼 𝘼𝙄 2026"


// Settings All Payment
global.dana = "083899782574" // ubah jadi nomor dana kalian 
global.gopay = "083138675899" // ubah jadi nomor gopay kalian


// Settings Image Url
global.image = {
// gambar menu awal
menu: "https://files.catbox.moe/rbmkex.jpg",
// menu v 2
menuv2: "https://files.catbox.moe/00gk3d.jpg", 
//banner welcome 
welcome: "https://img1.pixhost.to/images/9307/649554070_media.jpg", 
//banner left 
left: "https://img1.pixhost.to/images/9307/649554070_media.jpg", 
// logo saat bot reply pesan
reply: "https://files.catbox.moe/7djirb.jpg", 
levelup: "https://img1.pixhost.to/images/9319/649726402_media.jpg", 
// ubah jadi qris kalian
qris: "https://files.catbox.moe/z8lbo0.jpg"
}
// Message Command 
global.mess = {
    limit: `🎀 *Limit habis*\nSilakan ketik *.claim* untuk klaim bonus limit\nAtau *.buyprem* untuk upgrade ke Premium.`,
    owner: `🎀 *Akses ditolak*\nFitur ini hanya tersedia untuk *Mimin Yna*.`,
    verifikasi: `🎀 *Akses ditolak*\nSilakan ketik *.daftar* untuk mengakses seluruh fitur bot Yna Ai.`,
    admin: `🎀 *Akses ditolak*\nFitur ini khusus untuk *Admin Grup*.`,
    botAdmin: `🎀 *Akses ditolak*\nBot Yna Ai harus menjadi *Admin Grup* untuk menjalankan fitur ini.`,
    group: `🎀 *Akses ditolak*\nFitur ini hanya dapat digunakan di dalam *Grup*.`,
    private: `🎀 *Akses ditolak*\nFitur ini hanya dapat digunakan di *Chat Pribadi*.`,
    prem: `🎀 *Akses ditolak*\nFitur ini hanya tersedia untuk *User Premium*.\nKetik *.prem* untuk informasi upgrade.`,
    wait: `🎀 *Sabar Kak ya...*\nPermintaan sedang diproses.`,
    error: `🎀 *Terjadi kesalahan*\nSilakan coba kembali beberapa saat lagi.`,
    done: `🎀 *Done Kak ✅*\nProses telah diselesaikan.`
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})
