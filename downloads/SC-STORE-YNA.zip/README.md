## Rules & Guidelines
1. Dilarang keras membagikan script secara cuma cuma.
2. Jangan menghapus credit yang ada di script.  
3. Permintaan fitur untuk update diperbolehkan, selama masuk akal.  
4. Bot akan selalu diperbarui dan dikembangkan secara berkala.

# RENAME SCRIP CUKUP BAGIAN ( SETTING.JS ) DILARANG KERAS BYPASS DB BOT/ATAU MENCOPOT SISTEM DB!!!

## Cara Menjalankan Script
1. Upload file ke panel hosting.  
2. Ekstrak (unarchive) file script.  
3. Pilih Node.js versi 23 atau lebih tinggi.  
4. Masukkan password pairing yang telah diberikan.  
5. Masukkan nomor bot.

© 2025-2026 @Yna_Developer__

## New update v8.5.0

`new fitur`
___________
1. .swgcall
2. .setclose
3. .setopen
4. penambahan variabel gaya prefix di .setlist
5. .unreg
6. .bratgambarhd
7. .setmenu
8. .pindl

`fix fitur`
___________
1. all maker menu ( banana ai )
2. .cekkalender
3. .setpay sekarang lebih mudah di gunakan
4. .toimg all stiker
5. .artinama
6. .play
7. .playch
8. .ytmp4
9. .bratanime
10. .rch
11. .telesticker
12. .bratanime
13. .ocr
14. .ig
15. auto downloader ig
16. fix auto downloader pinterest.
17. .smeme
18. .setppbot
19. .playvid ( youtube )