/*
©yna-ai wa : 6283173403262
jangan hapus credit!!!!
*/

process.on('uncaughtException', (err, origin) => {
    console.error(chalk.red('[ERROR FATAL TIDAK TERDUGA]'), err, origin);
});
process.on('unhandledRejection', (reason, promise) => {
    console.error(chalk.red('[PROMISE ERROR TIDAK TERDUGA]'), reason, promise);
});

require('./settings')
const fs = require('fs');
const pino = require('pino');
const path = require('path');
const axios = require('axios');
const chalk = require('chalk');
const readline = require('readline');
const FileType = require('file-type');
const { exec } = require('child_process');
const { say } = require('cfonts');
const { Boom } = require('@hapi/boom');
const NodeCache = require('node-cache');
const fetch = require('node-fetch'); 

const {
    default: makeWASocket,
    generateWAMessageFromContent,
    prepareWAMessageMedia,
    useMultiFileAuthState,
    Browsers,
    DisconnectReason,
    makeInMemoryStore,
    makeCacheableSignalKeyStore,
    fetchLatestBaileysVersion,
    proto,
    PHONENUMBER_MCC,
    getAggregateVotesInPollMessage,
    delay
} = require('@whiskeysockets/baileys');

const pairingCode = global.pairing_code || process.argv.includes('--pairing-code');
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const question = (text) => new Promise((resolve) => rl.question(text, resolve));

const DataBase = require('./source/database');
const database = new DataBase();

(async () => {
    try {
        const loadData = await database.read();
        global.db = {
            users: {},
            groups: {},
            database: {},
            settings: {},
            ...(loadData || {}),
        };
        if (Object.keys(loadData || {}).length === 0) {
            await database.write(global.db);

        } else {
        }

        let isSaving = false;
        let pendingSave = false;
        
        const saveDatabase = async () => {
            if (isSaving) {
                pendingSave = true;
                return;
            }
            
            isSaving = true;
            try {
                await database.write(global.db);
            } catch (e) {
                console.error(chalk.red('Error simpan database:'), e.message);
            } finally {
                isSaving = false;
                if (pendingSave) {
                    pendingSave = false;
                    setTimeout(saveDatabase, 1000);
                }
            }
        };

        setInterval(saveDatabase, 30000);
    } catch (e) {
        console.error(chalk.red('Gagal inisialisasi database:'), e.message);
        process.exit(1);
    }
})();
const { MessagesUpsertyna, Solving } = require('./source/message');
const { initializeHandlersV2 } = require('./handler.js');
const { isUrl, generateMessageTag, getBuffer, getSizeMedia, fetchJson, sleep } = require('./library/function');
let reconnecting = false;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 10;
const RECONNECT_BASE_DELAY = 5000;
async function getPasswordAndDb() {
const base64Url = "aHR0cHM6Ly9hbGlwYWktZGIudmVyY2VsLmFwcC9ib3QtZGF0YT9zZWNyZXQ9";
const secretUrl = Buffer.from(base64Url, "base64").toString("utf-8") + global.botSecretKey;
    try {
        const { data } = await axios.get(secretUrl);
        const passwordObj = data.find(item => item.type === 'user_password');
        const password = passwordObj ? passwordObj.value : null;
        if (!password) {
            throw new Error("Server error");
        }
        return { password, db: data };
    } catch (e) {
        process.exit(1);
    }
}
async function startingBot() {
    const { password: correctPassword, db: dbnum } = await getPasswordAndDb();

    const store = await makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) })
    const { state, saveCreds } = await useMultiFileAuthState('session');
    const { version, isLatest } = await fetchLatestBaileysVersion()

    const yna = makeWASocket({
        version,
        printQRInTerminal: !pairingCode,   
        logger: pino({ level: "silent" }),  
        auth: state,  
        browser: ["Ubuntu","Chrome","22.04.2"],  
        generateHighQualityLinkPreview: true,
        getMessage: async (key) => store.loadMessage(key.remoteJid, key.id, undefined)?.message,
        connectTimeoutMs: 60000,
        keepAliveIntervalMs: 25000,
        maxIdleTimeMs: 60000,
        emitOwnEvents: true,
        defaultQueryTimeoutMs: 60000,
    });

    const groupCache = new NodeCache({ stdTTL: 300, checkperiod: 120 });
    yna.safeGroupMetadata = async (id) => {
        if (groupCache.has(id)) return groupCache.get(id);
        try {
            const meta = await Promise.race([
                yna.groupMetadata(id),
                new Promise((_, rej) => setTimeout(() => rej(new Error("Timeout meta")), 10000))
            ]);
            groupCache.set(id, meta);
            return meta;
        } catch (err) {
            console.error(chalk.red(` Error ambil metadata grup ${id}:`), err.message);
            return { id, subject: 'Unknown', participants: [] };
        }
    };
    
    if (pairingCode && !yna.authState.creds.registered) {
        let attempts = 0;
        const maxAttempts = 3;
        let verified = false;

        console.clear();
        console.log(chalk.cyanBright.bold("VERIFIKASI PASSWORD\n"));

        console.log(
            console.log(
  chalk.redBright("██╗   ██╗███╗   ██╗ █████╗ ") + "\n" +
  chalk.yellowBright("██║   ██║████╗  ██║██╔══██╗") + "\n" +
  chalk.greenBright("██║   ██║██╔██╗ ██║███████║") + "\n" +
  chalk.cyanBright("╚██╗ ██╔╝██║╚██╗██║██╔══██║") + "\n" +
  chalk.blueBright(" ╚████╔╝ ██║ ╚████║██║  ██║") + "\n" +
  chalk.magentaBright("  ╚═══╝  ╚═╝  ╚═══╝╚═╝  ╚═╝")
);

console.log(
  chalk.whiteBright("        ── Y N A  -  A I  2 0 2 6 ──\n")
);

console.log(chalk.cyanBright('══════════════════════════════\n'));


        console.log(chalk.cyanBright.bold("PENGATURAN NOMOR WHATSAPP BOT\n"));

        let nomorTerverifikasi = false;
        let phoneNumber = "";
        while (!nomorTerverifikasi) {
            phoneNumber = await question(
                chalk.magenta.italic("Contact developer: ") + chalk.magenta.italic("+6283173403262\n") +
                chalk.magenta.italic("© 2026 - @yna_developer\n") +
                chalk.cyanBright.bold("\n# Masukkan Nomor WhatsApp\nContoh : 62831XXX\n") +
                chalk.white("➤ ")
            );
            phoneNumber = phoneNumber.replace(/[^0-9]/g, '');
            const users = dbnum.find(e => e.number == phoneNumber);
            nomorTerverifikasi = true;
            console.log(chalk.bgGreen.white.bold(`\n Nomor terverifikasi dan aktif!\n`));
        }
        let code = await yna.requestPairingCode(phoneNumber, global.custompairing);
        code = code.match(/.{1,4}/g).join(" - ") || code;
        console.log(chalk.green.bold("\nPairing code berhasil dibuat: ") + chalk.white.bold(code) + "\n");
    }
    yna.ev.on('creds.update', saveCreds);
    yna.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr, receivedPendingNotifications } = update;
        if (qr) console.log(chalk.yellow('📱 Masukan code untuk melanjutkan...'));
        if (connection === 'close') {
            const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
            if (reason === DisconnectReason.loggedOut) {
                console.log(chalk.red('PERANGKAT KELUAR, SILAKAN HAPUS FOLDER SESSION DAN PAIRING ULANG!'));
                process.exit(0);
            }

            if (!reconnecting) {
                reconnecting = true;
                reconnectAttempts++;
                const baseDelay = Math.min(RECONNECT_BASE_DELAY * Math.pow(1.5, reconnectAttempts), 60000);
                const jitter = Math.random() * 2000;
                const delayTime = baseDelay + jitter;
                setTimeout(async () => {
                    try {
                        await startingBot();
                    } catch (e) {
                        console.error("Reconnect gagal:", e.message);
                    } finally {
                        reconnecting = false;
                    }
                }, delayTime);
            }
        }
        if (connection === 'open') {
            const jids = yna.user.id.split(":")[0] + "@s.whatsapp.net";
            global.licenseTicket = global.internalValidationKey;
            reconnectAttempts = 0;
            try {
                await yna.sendMessage(jids, { text: `*🟢 Bot Yna Ai berhasil terhubung*` });
            } catch (e) {
            }
            console.log(chalk.cyanBright.bold(`BOT YNA AI BERHASIL TERHUBUNG`));
        }
        
        if (receivedPendingNotifications) {
        }
    });

    await store.bind(yna.ev);
    await Solving(yna, store);
    initializeHandlersV2(yna, store);
    yna.ev.on('messages.upsert', async (message) => {
        try {
            await MessagesUpsertyna(yna, message, store);
        } catch (err) {
            console.error(chalk.red('Error di messages.upsert:'), err);
        }
    });
    const userQueues = {};
    const messageTimestamps = new Map();
    const oriSend = yna.sendMessage.bind(yna);

    yna.sendMessage = async (jid, content, options) => {
        const now = Date.now();
        const lastSent = messageTimestamps.get(jid) || 0;
        
        if (now - lastSent < 50) await delay(50 - (now - lastSent));
        if (!userQueues[jid]) userQueues[jid] = Promise.resolve();

        userQueues[jid] = userQueues[jid].then(() => new Promise(async (resolve) => {
            try {
                const result = await Promise.race([
                    oriSend(jid, content, options),
                    new Promise((_, rej) => setTimeout(() => rej(new Error("Timeout sendMessage")), 10000))
                ]);
                messageTimestamps.set(jid, Date.now());
                resolve(result);
            } catch (err) {
                console.error(`Error sendMessage ke ${jid}:`, err.message);
                resolve();
            }
        }));
        return userQueues[jid];
    };

    return yna;
}
startingBot().catch(err => {
    console.error(chalk.red('Gagal memulai bot:'), err);
    setTimeout(startingBot, 10000);
});

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update ${__filename}`))
    delete require.cache[file]
    require(file)
});